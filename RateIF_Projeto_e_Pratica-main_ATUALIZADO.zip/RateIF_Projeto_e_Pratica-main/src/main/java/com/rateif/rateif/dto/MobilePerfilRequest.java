package com.rateif.rateif.dto;

public record MobilePerfilRequest(
        String nome,
        String email
) {}
