package com.rateif.rateif.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rateif.rateif.dto.MobileDashboardResponse;
import com.rateif.rateif.repository.AlunoRepository;
import com.rateif.rateif.repository.AvaliacaoRepository;
import com.rateif.rateif.repository.RelatorioRepository;
import com.rateif.rateif.repository.TurmaRepository;
import com.rateif.rateif.repository.UsuarioRepository;
import com.rateif.rateif.service.MobileTokenService;

@RestController
@RequestMapping("/api/mobile/dashboard")
@CrossOrigin(origins = "*")
public class MobileDashboardController {

    private final UsuarioRepository usuarioRepository;
    private final AlunoRepository alunoRepository;
    private final TurmaRepository turmaRepository;
    private final AvaliacaoRepository avaliacaoRepository;
    private final RelatorioRepository relatorioRepository;
    private final MobileTokenService tokenService;

    public MobileDashboardController(
            UsuarioRepository usuarioRepository,
            AlunoRepository alunoRepository,
            TurmaRepository turmaRepository,
            AvaliacaoRepository avaliacaoRepository,
            RelatorioRepository relatorioRepository,
            MobileTokenService tokenService) {
        this.usuarioRepository = usuarioRepository;
        this.alunoRepository = alunoRepository;
        this.turmaRepository = turmaRepository;
        this.avaliacaoRepository = avaliacaoRepository;
        this.relatorioRepository = relatorioRepository;
        this.tokenService = tokenService;
    }

    @GetMapping
    public ResponseEntity<?> dashboard(
            @RequestHeader(value = "Authorization", required = false) String authorization) {
        try {
            int userId = tokenService.validateBearer(authorization).userId();
            boolean ativo = usuarioRepository.findById(userId)
                    .map(u -> Boolean.TRUE.equals(u.getStatus()))
                    .orElse(false);
            if (!ativo) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("mensagem", "Sessão mobile inválida ou expirada."));
            }
        } catch (MobileTokenService.InvalidMobileTokenException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("mensagem", "Sessão mobile inválida ou expirada."));
        }

        return ResponseEntity.ok(new MobileDashboardResponse(
                alunoRepository.count(),
                turmaRepository.count(),
                avaliacaoRepository.count(),
                relatorioRepository.count()
        ));
    }
}
