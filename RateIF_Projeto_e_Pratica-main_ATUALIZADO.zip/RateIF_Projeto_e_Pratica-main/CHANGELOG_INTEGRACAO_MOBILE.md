# Atualização — Cards "Esta semana"

## Integração Mobile
- Adicionado `mobile/` com React Native + Expo SDK 57.
- Login e cadastro do aplicativo usam API REST própria do Spring Boot.
- Token é armazenado com Expo Secure Store.
- Preparado para EAS Build (`development`, `preview`, `preview-apk`, `production`).

## Atualização do Backend
- Adicionados endpoints `/api/mobile/auth/*`, `/api/mobile/profile` e `/api/mobile/dashboard`.
- Adicionada autenticação stateless com token assinado por HMAC-SHA256, sem nova tabela no banco.
- Reutilizados `UsuarioRepository`, `AlunoRepository`, `TurmaRepository`, `AvaliacaoRepository` e `RelatorioRepository`.
- Adicionado CORS para a API mobile.
- A autenticação web existente em `/auth/*` e as páginas Thymeleaf permanecem no projeto.

## Tela de Perfil
- Criada tela mobile para consultar e editar nome/e-mail.
- O backend valida conflito de e-mail e devolve um novo token após alteração.

## Validações realizadas neste ambiente
- JSON do `package.json`, `app.json` e `eas.json` validado.
- Sintaxe dos arquivos JavaScript do mobile validada com `node --check`.
- XML do `pom.xml` validado.
- Estrutura e balanceamento de chaves dos arquivos Java adicionados verificados.
- O build Maven completo não pôde ser executado neste ambiente porque o Maven Wrapper precisou baixar o Maven da internet e a conexão de download ficou indisponível.
