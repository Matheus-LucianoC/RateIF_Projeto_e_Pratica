# RateIF Mobile

Aplicativo React Native com Expo integrado diretamente à API REST do backend Spring Boot do RateIF.

## Stack

- React Native 0.86
- Expo SDK 57
- Expo Secure Store
- EAS Build
- API REST do Spring Boot
- MySQL/MariaDB através do backend

## Configuração

```cmd
npm install
```

Crie `.env` a partir de `.env.example`:

```env
EXPO_PUBLIC_API_URL=http://192.168.0.100:8080
```

Depois:

```cmd
npx expo start
```

Veja `../README_MOBILE_INTEGRACAO.md` para o fluxo completo do backend e EAS.
