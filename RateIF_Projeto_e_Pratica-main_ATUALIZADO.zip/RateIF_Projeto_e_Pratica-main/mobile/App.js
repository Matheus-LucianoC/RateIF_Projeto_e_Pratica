import React, { useState } from "react";
import { ActivityIndicator, SafeAreaView, StatusBar, StyleSheet, View } from "react-native";

import { AuthProvider, useAuth } from "./src/context/AuthContext";
import { CadastroScreen } from "./src/screens/CadastroScreen";
import { HomeScreen } from "./src/screens/HomeScreen";
import { LoginScreen } from "./src/screens/LoginScreen";
import { ProfileScreen } from "./src/screens/ProfileScreen";

function MobileApp() {
  const { loading, autenticado } = useAuth();
  const [authScreen, setAuthScreen] = useState("login");
  const [appScreen, setAppScreen] = useState("home");

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  if (!autenticado) {
    return authScreen === "cadastro" ? (
      <CadastroScreen onVoltar={() => setAuthScreen("login")} />
    ) : (
      <LoginScreen onCadastrar={() => setAuthScreen("cadastro")} />
    );
  }

  if (appScreen === "profile") {
    return <ProfileScreen onVoltar={() => setAppScreen("home")} />;
  }

  return <HomeScreen onPerfil={() => setAppScreen("profile")} />;
}

export default function App() {
  return (
    <AuthProvider>
      <SafeAreaView style={styles.safeArea}>
        <StatusBar barStyle="light-content" />
        <MobileApp />
      </SafeAreaView>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: "#111318" },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#111318" },
});
