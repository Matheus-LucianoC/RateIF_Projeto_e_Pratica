import React from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text } from "react-native";

export function PrimaryButton({ title, onPress, loading = false, secondary = false }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={loading}
      style={({ pressed }) => [
        styles.button,
        secondary ? styles.secondary : styles.primary,
        pressed && styles.pressed,
      ]}
    >
      {loading ? (
        <ActivityIndicator />
      ) : (
        <Text style={[styles.label, secondary && styles.secondaryLabel]}>{title}</Text>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    minHeight: 52,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 18,
    marginTop: 12,
  },
  primary: { backgroundColor: "#f4c84a" },
  secondary: { backgroundColor: "#20242b", borderWidth: 1, borderColor: "#343944" },
  label: { color: "#111318", fontSize: 16, fontWeight: "800" },
  secondaryLabel: { color: "#f2f4f8" },
  pressed: { opacity: 0.78 },
});
