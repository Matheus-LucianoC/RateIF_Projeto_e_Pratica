import React from "react";
import { StyleSheet, Text, View } from "react-native";

export function Card({ title, value, description }) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.description}>{description}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minHeight: 118,
    padding: 16,
    margin: 5,
    borderRadius: 16,
    backgroundColor: "#20242b",
    borderWidth: 1,
    borderColor: "#303641",
  },
  title: { color: "#c8ccd4", fontSize: 13, fontWeight: "700" },
  value: { color: "#f4c84a", fontSize: 28, fontWeight: "900", marginTop: 10 },
  description: { color: "#7f8794", fontSize: 12, marginTop: 5 },
});
