import React from "react";
import { StyleSheet, Text, TextInput, View } from "react-native";

export function Input({ label, ...props }) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        {...props}
        style={styles.input}
        placeholderTextColor="#777d89"
        autoCapitalize={props.autoCapitalize ?? "none"}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 12 },
  label: { color: "#b9bec8", fontSize: 13, marginBottom: 7, fontWeight: "700" },
  input: {
    minHeight: 52,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#343944",
    backgroundColor: "#20242b",
    color: "#f4f6fa",
    paddingHorizontal: 15,
    fontSize: 16,
  },
});
