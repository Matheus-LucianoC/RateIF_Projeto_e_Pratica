import React, { useEffect, useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text } from "react-native";

import { Input } from "../components/Input";
import { PrimaryButton } from "../components/PrimaryButton";
import { useAuth } from "../context/AuthContext";
import { mobileApi } from "../api";

export function ProfileScreen({ onVoltar }) {
  const { token, usuario, atualizarPerfil } = useAuth();
  const [nome, setNome] = useState(usuario?.nome || "");
  const [email, setEmail] = useState(usuario?.email || "");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setNome(usuario?.nome || "");
    setEmail(usuario?.email || "");
  }, [usuario]);

  async function salvar() {
    if (!nome.trim() || !email.trim()) {
      Alert.alert("Perfil", "Nome e e-mail são obrigatórios.");
      return;
    }

    try {
      setLoading(true);
      const data = await atualizarPerfil(nome.trim(), email.trim());
      Alert.alert("Perfil", data.mensagem);
    } catch (error) {
      Alert.alert("Perfil", error.message);
    } finally {
      setLoading(false);
    }
  }

  async function recarregar() {
    try {
      const data = await mobileApi.perfil(token);
      setNome(data.nome || "");
      setEmail(data.email || "");
    } catch (error) {
      Alert.alert("Perfil", error.message);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.back} onPress={onVoltar}>‹  Voltar</Text>
        <Text style={styles.title}>Meu perfil</Text>
        <Text style={styles.subtitle}>Os dados abaixo são carregados do usuário salvo no banco do RateIF.</Text>

        <Input label="Nome" value={nome} onChangeText={setNome} autoCapitalize="words" placeholder="Seu nome" />
        <Input label="E-mail" value={email} onChangeText={setEmail} keyboardType="email-address" placeholder="seu@email.com" />

        <Text style={styles.readonly}>Perfil: {usuario?.perfil || "USUARIO"}</Text>
        <Text style={styles.readonly}>Status: {usuario?.status ? "Ativo" : "Inativo"}</Text>

        <PrimaryButton title="Salvar alterações" onPress={salvar} loading={loading} />
        <PrimaryButton title="Recarregar dados" onPress={recarregar} secondary />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  container: { flexGrow: 1, padding: 24, backgroundColor: "#111318" },
  back: { color: "#f4c84a", fontSize: 16, fontWeight: "800", marginTop: 16, marginBottom: 24 },
  title: { color: "#f4f6fa", fontSize: 30, fontWeight: "900" },
  subtitle: { color: "#8d94a1", lineHeight: 20, marginTop: 8, marginBottom: 26 },
  readonly: { color: "#8d94a1", marginTop: 9 },
});
