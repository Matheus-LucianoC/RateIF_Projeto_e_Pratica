import React, { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from "react-native";

import { Input } from "../components/Input";
import { PrimaryButton } from "../components/PrimaryButton";
import { useAuth } from "../context/AuthContext";

export function LoginScreen({ onCadastrar }) {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [loading, setLoading] = useState(false);

  async function entrar() {
    if (!email.trim() || !senha) {
      Alert.alert("Login", "Informe seu e-mail e sua senha.");
      return;
    }

    try {
      setLoading(true);
      await login(email.trim(), senha);
    } catch (error) {
      Alert.alert("Não foi possível entrar", error.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <View style={styles.logoCircle}><Text style={styles.logoText}>R</Text></View>
        <Text style={styles.title}>RateIF</Text>
        <Text style={styles.subtitle}>Acompanhamento acadêmico e pedagógico</Text>

        <View style={styles.form}>
          <Input label="E-mail" value={email} onChangeText={setEmail} keyboardType="email-address" placeholder="seu@email.com" />
          <Input label="Senha" value={senha} onChangeText={setSenha} secureTextEntry placeholder="••••••••" />
          <PrimaryButton title="Entrar" onPress={entrar} loading={loading} />
          <PrimaryButton title="Criar uma conta" onPress={onCadastrar} secondary />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  container: { flexGrow: 1, justifyContent: "center", padding: 24, backgroundColor: "#111318" },
  logoCircle: { width: 72, height: 72, borderRadius: 36, backgroundColor: "#f4c84a", alignSelf: "center", alignItems: "center", justifyContent: "center" },
  logoText: { fontSize: 38, fontWeight: "900", color: "#111318" },
  title: { color: "#f4f6fa", fontSize: 38, fontWeight: "900", textAlign: "center", marginTop: 14 },
  subtitle: { color: "#8d94a1", fontSize: 14, textAlign: "center", lineHeight: 20, marginTop: 6 },
  form: { marginTop: 30 },
});
