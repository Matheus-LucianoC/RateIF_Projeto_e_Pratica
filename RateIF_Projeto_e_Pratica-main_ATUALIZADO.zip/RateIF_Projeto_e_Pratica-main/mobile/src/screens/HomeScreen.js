import React, { useCallback, useEffect, useState } from "react";
import { Alert, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";

import { Card } from "../components/Card";
import { PrimaryButton } from "../components/PrimaryButton";
import { useAuth } from "../context/AuthContext";
import { mobileApi } from "../api";

export function HomeScreen({ onPerfil }) {
  const { token, usuario, logout } = useAuth();
  const [dashboard, setDashboard] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const carregar = useCallback(async () => {
    try {
      const data = await mobileApi.dashboard(token);
      setDashboard(data);
    } catch (error) {
      Alert.alert("Dashboard", error.message);
    }
  }, [token]);

  useEffect(() => {
    carregar();
  }, [carregar]);

  async function refresh() {
    setRefreshing(true);
    try {
      await carregar();
    } finally {
      setRefreshing(false);
    }
  }

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
    >
      <View style={styles.header}>
        <View>
          <Text style={styles.kicker}>BEM-VINDO</Text>
          <Text style={styles.title}>{usuario?.nome || "Usuário"}</Text>
          <Text style={styles.subtitle}>{usuario?.perfil || "USUARIO"}</Text>
        </View>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{(usuario?.nome || "U").charAt(0).toUpperCase()}</Text>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Resumo do RateIF</Text>
      <View style={styles.grid}>
        <Card title="Alunos" value={dashboard?.alunos ?? "—"} description="registros no banco" />
        <Card title="Turmas" value={dashboard?.turmas ?? "—"} description="turmas cadastradas" />
        <Card title="Avaliações" value={dashboard?.avaliacoes ?? "—"} description="avaliações registradas" />
        <Card title="Relatórios" value={dashboard?.relatorios ?? "—"} description="relatórios registrados" />
      </View>

      <Text style={styles.sectionTitle}>Acesso rápido</Text>
      <PrimaryButton title="Meu perfil" onPress={onPerfil} />
      <PrimaryButton title="Sair" onPress={logout} secondary />

      <View style={styles.footerCard}>
        <Text style={styles.footerTitle}>Integração ativa</Text>
        <Text style={styles.footerText}>
          Este aplicativo consulta o Spring Boot do RateIF através da API REST própria. O MySQL continua sendo acessado somente pelo backend.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#111318" },
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 28, paddingTop: 20 },
  kicker: { color: "#f4c84a", fontSize: 12, fontWeight: "900", letterSpacing: 1.3 },
  title: { color: "#f4f6fa", fontSize: 28, fontWeight: "900", marginTop: 6 },
  subtitle: { color: "#8d94a1", marginTop: 3 },
  avatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: "#f4c84a", alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#111318", fontSize: 22, fontWeight: "900" },
  sectionTitle: { color: "#f4f6fa", fontSize: 18, fontWeight: "800", marginBottom: 10, marginTop: 6 },
  grid: { flexDirection: "row", flexWrap: "wrap", marginHorizontal: -5, marginBottom: 18 },
  footerCard: { marginTop: 22, padding: 16, borderRadius: 16, backgroundColor: "#1a1d23", borderWidth: 1, borderColor: "#2c313a" },
  footerTitle: { color: "#f4c84a", fontWeight: "800", marginBottom: 7 },
  footerText: { color: "#8d94a1", lineHeight: 20 },
});
