import React, { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text } from "react-native";

import { Input } from "../components/Input";
import { PrimaryButton } from "../components/PrimaryButton";
import { useAuth } from "../context/AuthContext";

export function CadastroScreen({ onVoltar }) {
  const { cadastro } = useAuth();
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");
  const [loading, setLoading] = useState(false);

  async function criarConta() {
    if (!nome.trim() || !email.trim() || !senha || !confirmarSenha) {
      Alert.alert("Cadastro", "Preencha todos os campos.");
      return;
    }

    try {
      setLoading(true);
      await cadastro(nome.trim(), email.trim(), senha, confirmarSenha);
    } catch (error) {
      Alert.alert("Não foi possível criar a conta", error.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>Criar conta</Text>
        <Text style={styles.subtitle}>O cadastro será salvo no mesmo banco utilizado pelo RateIF.</Text>

        <Input label="Nome" value={nome} onChangeText={setNome} autoCapitalize="words" placeholder="Seu nome" />
        <Input label="E-mail" value={email} onChangeText={setEmail} keyboardType="email-address" placeholder="seu@email.com" />
        <Input label="Senha" value={senha} onChangeText={setSenha} secureTextEntry placeholder="Mínimo de 6 caracteres" autoCapitalize="none" />
        <Input label="Confirmar senha" value={confirmarSenha} onChangeText={setConfirmarSenha} secureTextEntry placeholder="Repita a senha" autoCapitalize="none" />

        <PrimaryButton title="Cadastrar" onPress={criarConta} loading={loading} />
        <PrimaryButton title="Voltar para o login" onPress={onVoltar} secondary />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  container: { flexGrow: 1, justifyContent: "center", padding: 24, backgroundColor: "#111318" },
  title: { color: "#f4f6fa", fontSize: 30, fontWeight: "900", marginBottom: 8 },
  subtitle: { color: "#8d94a1", lineHeight: 20, marginBottom: 28 },
});
