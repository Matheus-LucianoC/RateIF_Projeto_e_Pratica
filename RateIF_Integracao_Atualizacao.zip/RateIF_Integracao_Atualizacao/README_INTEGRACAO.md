# RateIF — atualização da coluna “Esta semana”

Esta entrega organiza os três cards do print como código funcional:

- **Integração Mobile** → aplicativo React Native/Expo separado, consumindo a API do próprio Spring Boot.
- **Atualização do Backend** → novos endpoints `/api/mobile/...`, usando as entidades, repositório JPA e BCrypt que já existem no projeto.
- **Tela de Perfil** → tela mobile de leitura/edição de nome e e-mail, persistindo no MySQL através do Spring Boot.

## Arquitetura adotada

```text
React Native / Expo
        |
        | HTTPS + Authorization: Bearer <token>
        v
Spring Boot (RateIF atual)
        |
        +-- /api/mobile/auth/login
        +-- /api/mobile/auth/cadastro
        +-- /api/mobile/usuarios/me
        +-- /api/mobile/usuarios/me  (PUT)
        |
        v
UsuarioRepository / Usuario / BCrypt
        |
        v
MySQL: sistema_escolar
```

A web existente continua usando as rotas `/auth/...` e `HttpSession`. O mobile usa uma camada de API própria para não depender do cookie de sessão do navegador.

## 1. Atualizar o backend

Copie a pasta:

```text
backend/src/main/java/com/rateif/rateif/mobile/
```

para dentro de:

```text
RateIF_Projeto_e_Pratica/src/main/java/com/rateif/rateif/mobile/
```

Depois, acrescente o conteúdo de:

```text
backend/application.properties.mobile-snippet
```

no seu:

```text
src/main/resources/application.properties
```

### Endpoints adicionados

`POST /api/mobile/auth/login`

```json
{
  "email": "usuario@exemplo.com",
  "senha": "123456"
}
```

`POST /api/mobile/auth/cadastro`

```json
{
  "nome": "Usuário Teste",
  "email": "usuario@exemplo.com",
  "senha": "123456",
  "confirmarSenha": "123456"
}
```

`GET /api/mobile/usuarios/me`

Header:

```text
Authorization: Bearer SEU_TOKEN
```

`PUT /api/mobile/usuarios/me`

Header:

```text
Authorization: Bearer SEU_TOKEN
```

Body:

```json
{
  "nome": "Nome atualizado",
  "email": "novoemail@exemplo.com"
}
```

## 2. Rodar o Spring Boot

No projeto principal:

```powershell
.\\mvnw.cmd spring-boot:run
```

Por padrão, a aplicação deve responder em `http://localhost:8080`.

## 3. Configurar o Expo

Entre na pasta mobile:

```powershell
cd mobile
npm install
```

Crie um arquivo `.env` a partir do `.env.example`.

### Celular físico

Use o IP da máquina que está executando o Spring Boot, por exemplo:

```env
EXPO_PUBLIC_API_URL=http://192.168.0.100:8080
```

O celular e o computador precisam estar na mesma rede local.

### Android Emulator

```env
EXPO_PUBLIC_API_URL=http://10.0.2.2:8080
```

### iOS Simulator

```env
EXPO_PUBLIC_API_URL=http://127.0.0.1:8080
```

Depois:

```powershell
npx expo start
```

## 4. Fluxo implementado

1. Login envia e-mail/senha para o Spring Boot.
2. Spring Boot valida com `UsuarioRepository` + BCrypt.
3. Backend retorna um Bearer token e os dados do usuário.
4. O app salva o token localmente com AsyncStorage.
5. A Home usa os dados vindos da API.
6. A tela Perfil consulta `/api/mobile/usuarios/me` e atualiza com `PUT /api/mobile/usuarios/me`.
7. Ao sair, o app remove o token local.

## 5. EAS Build

Na pasta `mobile`:

```powershell
npm install
npm install -g eas-cli
eas login
eas build:configure
```

Para uma build de teste:

```powershell
eas build -p android --profile preview
```

Para produção:

```powershell
eas build -p android --profile production
```

No EAS, configure `EXPO_PUBLIC_API_URL` apontando para o endereço HTTPS público do backend. Não use `localhost` na versão instalada em um aparelho físico.

## 6. Observação sobre o token mobile

O projeto usa um Bearer token assinado com HMAC-SHA256 e não depende do `JSESSIONID` do navegador. Para produção, defina `RATEIF_MOBILE_TOKEN_SECRET` como uma chave longa e aleatória no ambiente do backend.

A expiração padrão está configurada em 24 horas por meio de `rateif.mobile.token-expiration-minutes=1440`.

## 7. O que foi preservado

O código novo não substitui as entidades ou repositórios existentes. Ele reutiliza:

- `Usuario`;
- `UsuarioRepository`;
- validações de e-mail/cadastro já presentes no domínio;
- BCrypt já utilizado pelo `AuthController`;
- o banco `sistema_escolar`.

Assim, o backend Spring Boot continua sendo o ponto central de autenticação e persistência, e o React Native funciona como um cliente do mesmo sistema.
