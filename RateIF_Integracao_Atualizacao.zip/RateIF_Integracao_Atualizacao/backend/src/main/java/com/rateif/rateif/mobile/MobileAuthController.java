package com.rateif.rateif.mobile;

import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rateif.rateif.mobile.dto.MobileAuthResponse;
import com.rateif.rateif.mobile.dto.MobileCadastroRequest;
import com.rateif.rateif.mobile.dto.MobileLoginRequest;
import com.rateif.rateif.mobile.dto.MobileUsuarioResponse;
import com.rateif.rateif.model.Usuario;
import com.rateif.rateif.repository.UsuarioRepository;

@RestController
@RequestMapping("/api/mobile/auth")
public class MobileAuthController {

    private final UsuarioRepository usuarioRepository;
    private final MobileTokenService tokenService;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public MobileAuthController(
            UsuarioRepository usuarioRepository,
            MobileTokenService tokenService) {
        this.usuarioRepository = usuarioRepository;
        this.tokenService = tokenService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody MobileLoginRequest request) {
        if (request == null || vazio(request.email()) || vazio(request.senha())) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Preencha e-mail e senha."));
        }

        String email = request.email().trim().toLowerCase(Locale.ROOT);
        Usuario usuario = usuarioRepository.findByEmailIgnoreCase(email).orElse(null);

        if (usuario == null
                || !Boolean.TRUE.equals(usuario.getStatus())
                || !passwordEncoder.matches(request.senha(), usuario.getSenhaHash())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("mensagem", "E-mail ou senha inválidos."));
        }

        String token = tokenService.createToken(usuario);
        return ResponseEntity.ok(new MobileAuthResponse(
                "Login realizado com sucesso.",
                token,
                MobileUsuarioResponse.from(usuario)
        ));
    }

    @PostMapping("/cadastro")
    public ResponseEntity<?> cadastro(@RequestBody MobileCadastroRequest request) {
        if (request == null
                || vazio(request.nome())
                || vazio(request.email())
                || vazio(request.senha())
                || vazio(request.confirmarSenha())) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Preencha todos os campos."));
        }

        if (request.nome().trim().length() < 3) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Informe um nome válido."));
        }

        String email = request.email().trim().toLowerCase(Locale.ROOT);

        if (!email.contains("@") || !email.contains(".")) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Informe um e-mail válido."));
        }

        if (request.senha().length() < 6) {
            return ResponseEntity.badRequest()
                    .body(Map.of("mensagem", "A senha deve ter pelo menos 6 caracteres."));
        }

        if (!request.senha().equals(request.confirmarSenha())) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "As senhas não coincidem."));
        }

        if (usuarioRepository.existsByEmailIgnoreCase(email)) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("mensagem", "Já existe um usuário com esse e-mail."));
        }

        Usuario usuario = new Usuario();
        usuario.setNome(request.nome().trim());
        usuario.setEmail(email);
        usuario.setSenhaHash(passwordEncoder.encode(request.senha()));
        usuario.setPerfil("USUARIO");
        usuario.setStatus(true);
        usuario.setCriadoEm(LocalDateTime.now());
        usuario = usuarioRepository.save(usuario);

        String token = tokenService.createToken(usuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(new MobileAuthResponse(
                "Cadastro realizado com sucesso.",
                token,
                MobileUsuarioResponse.from(usuario)
        ));
    }

    private boolean vazio(String valor) {
        return valor == null || valor.isBlank();
    }
}
