package com.rateif.rateif.mobile.dto;

public record MobileAtualizarPerfilRequest(String nome, String email) {
}
