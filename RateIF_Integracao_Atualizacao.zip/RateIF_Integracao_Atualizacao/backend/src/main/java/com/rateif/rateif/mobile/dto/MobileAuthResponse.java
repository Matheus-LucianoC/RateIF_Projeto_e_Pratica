package com.rateif.rateif.mobile.dto;

public record MobileAuthResponse(
        String mensagem,
        String token,
        MobileUsuarioResponse usuario
) {
}
