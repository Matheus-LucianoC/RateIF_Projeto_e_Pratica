package com.rateif.rateif.mobile.dto;

public record MobileCadastroRequest(
        String nome,
        String email,
        String senha,
        String confirmarSenha
) {
}
