package com.rateif.rateif.mobile;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.UUID;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.rateif.rateif.model.Usuario;
import com.rateif.rateif.repository.UsuarioRepository;

@Service
public class MobileTokenService {

    private static final String HMAC_ALGORITHM = "HmacSHA256";

    private final UsuarioRepository usuarioRepository;
    private final String secret;
    private final long expirationMinutes;

    public MobileTokenService(
            UsuarioRepository usuarioRepository,
            @Value("${rateif.mobile.token-secret}") String secret,
            @Value("${rateif.mobile.token-expiration-minutes:1440}") long expirationMinutes) {
        this.usuarioRepository = usuarioRepository;
        this.secret = secret;
        this.expirationMinutes = expirationMinutes;
    }

    public String createToken(Usuario usuario) {
        long expiresAt = (System.currentTimeMillis() / 1000L) + (expirationMinutes * 60L);
        String payload = usuario.getId() + "." + expiresAt + "." + UUID.randomUUID();
        String encodedPayload = Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(payload.getBytes(StandardCharsets.UTF_8));
        String signature = sign(encodedPayload);
        return encodedPayload + "." + signature;
    }

    public Usuario requireUser(String authorizationHeader) {
        Integer userId = extractUserId(authorizationHeader);
        if (userId == null) {
            return null;
        }
        return usuarioRepository.findById(userId)
                .filter(usuario -> Boolean.TRUE.equals(usuario.getStatus()))
                .orElse(null);
    }

    private Integer extractUserId(String authorizationHeader) {
        if (authorizationHeader == null || authorizationHeader.isBlank()) {
            return null;
        }

        String prefix = "Bearer ";
        if (!authorizationHeader.regionMatches(true, 0, prefix, 0, prefix.length())) {
            return null;
        }

        String token = authorizationHeader.substring(prefix.length()).trim();
        String[] parts = token.split("\\.");
        if (parts.length != 2) {
            return null;
        }

        String expectedSignature = sign(parts[0]);
        if (!MessageDigest.isEqual(
                expectedSignature.getBytes(StandardCharsets.UTF_8),
                parts[1].getBytes(StandardCharsets.UTF_8))) {
            return null;
        }

        try {
            String payload = new String(
                    Base64.getUrlDecoder().decode(parts[0]),
                    StandardCharsets.UTF_8
            );
            String[] payloadParts = payload.split("\\.", 3);
            if (payloadParts.length < 2) {
                return null;
            }

            Integer userId = Integer.valueOf(payloadParts[0]);
            long expiresAt = Long.parseLong(payloadParts[1]);
            long now = System.currentTimeMillis() / 1000L;
            if (expiresAt <= now) {
                return null;
            }

            return userId;
        } catch (Exception ignored) {
            return null;
        }
    }

    private String sign(String value) {
        try {
            Mac mac = Mac.getInstance(HMAC_ALGORITHM);
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), HMAC_ALGORITHM));
            byte[] signature = mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(signature);
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException("Não foi possível assinar o token mobile.", exception);
        }
    }
}
