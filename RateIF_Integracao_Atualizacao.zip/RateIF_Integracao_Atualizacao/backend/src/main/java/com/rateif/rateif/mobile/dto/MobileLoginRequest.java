package com.rateif.rateif.mobile.dto;

public record MobileLoginRequest(String email, String senha) {
}
