package com.rateif.rateif.mobile;

import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rateif.rateif.mobile.dto.MobileAtualizarPerfilRequest;
import com.rateif.rateif.mobile.dto.MobileUsuarioResponse;
import com.rateif.rateif.model.Usuario;
import com.rateif.rateif.repository.UsuarioRepository;

@RestController
@RequestMapping("/api/mobile/usuarios")
public class MobileUsuarioController {

    private final UsuarioRepository usuarioRepository;
    private final MobileTokenService tokenService;

    public MobileUsuarioController(
            UsuarioRepository usuarioRepository,
            MobileTokenService tokenService) {
        this.usuarioRepository = usuarioRepository;
        this.tokenService = tokenService;
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(
            @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization) {
        Usuario usuario = tokenService.requireUser(authorization);
        if (usuario == null) {
            return unauthorized();
        }
        return ResponseEntity.ok(MobileUsuarioResponse.from(usuario));
    }

    @PutMapping("/me")
    public ResponseEntity<?> atualizarPerfil(
            @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization,
            @RequestBody MobileAtualizarPerfilRequest request) {
        Usuario usuario = tokenService.requireUser(authorization);
        if (usuario == null) {
            return unauthorized();
        }

        if (request == null || vazio(request.nome()) || vazio(request.email())) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Nome e e-mail são obrigatórios."));
        }

        String nome = request.nome().trim();
        String email = request.email().trim().toLowerCase(Locale.ROOT);

        if (nome.length() < 3) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Informe um nome válido."));
        }

        if (!email.contains("@") || !email.contains(".")) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Informe um e-mail válido."));
        }

        Optional<Usuario> outroUsuario = usuarioRepository.findByEmailIgnoreCase(email);
        if (outroUsuario.isPresent() && !outroUsuario.get().getId().equals(usuario.getId())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("mensagem", "Este e-mail já está em uso."));
        }

        usuario.setNome(nome);
        usuario.setEmail(email);
        usuario = usuarioRepository.save(usuario);

        return ResponseEntity.ok(Map.of(
                "mensagem", "Perfil atualizado com sucesso.",
                "usuario", MobileUsuarioResponse.from(usuario)
        ));
    }

    private ResponseEntity<Map<String, String>> unauthorized() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("mensagem", "Sessão mobile inválida ou expirada."));
    }

    private boolean vazio(String valor) {
        return valor == null || valor.isBlank();
    }
}
