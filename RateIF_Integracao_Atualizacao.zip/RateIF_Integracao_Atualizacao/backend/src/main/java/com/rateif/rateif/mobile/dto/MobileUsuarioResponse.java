package com.rateif.rateif.mobile.dto;

import com.rateif.rateif.model.Usuario;

public record MobileUsuarioResponse(
        Integer id,
        String nome,
        String email,
        String perfil,
        Boolean status
) {
    public static MobileUsuarioResponse from(Usuario usuario) {
        return new MobileUsuarioResponse(
                usuario.getId(),
                usuario.getNome(),
                usuario.getEmail(),
                usuario.getPerfil(),
                usuario.getStatus()
        );
    }
}
