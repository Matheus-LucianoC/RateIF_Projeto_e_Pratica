import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext, useEffect, useMemo, useState } from "react";

import { apiRequest, withBearer } from "../api/client";
import { API_ENDPOINTS } from "../config/api";

const TOKEN_KEY = "@rateif/token";
const USER_KEY = "@rateif/user";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    restoreSession();
  }, []);

  async function restoreSession() {
    try {
      const savedToken = await AsyncStorage.getItem(TOKEN_KEY);
      const savedUser = await AsyncStorage.getItem(USER_KEY);

      if (!savedToken) {
        return;
      }

      setToken(savedToken);
      if (savedUser) {
        setUser(JSON.parse(savedUser));
      }

      const currentUser = await apiRequest(API_ENDPOINTS.me, {
        method: "GET",
        headers: withBearer(savedToken),
      });

      await persistUser(currentUser);
    } catch {
      await clearSession();
    } finally {
      setLoading(false);
    }
  }

  async function persistUser(nextUser) {
    setUser(nextUser);
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(nextUser));
  }

  async function persistSession(nextToken, nextUser) {
    await AsyncStorage.setItem(TOKEN_KEY, nextToken);
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(nextUser));
    setToken(nextToken);
    setUser(nextUser);
  }

  async function login(email, senha) {
    const data = await apiRequest(API_ENDPOINTS.login, {
      method: "POST",
      body: JSON.stringify({ email, senha }),
    });
    await persistSession(data.token, data.usuario);
    return data;
  }

  async function register(nome, email, senha, confirmarSenha) {
    const data = await apiRequest(API_ENDPOINTS.cadastro, {
      method: "POST",
      body: JSON.stringify({ nome, email, senha, confirmarSenha }),
    });
    await persistSession(data.token, data.usuario);
    return data;
  }

  async function updateProfile(nome, email) {
    const data = await apiRequest(API_ENDPOINTS.profile, {
      method: "PUT",
      headers: withBearer(token),
      body: JSON.stringify({ nome, email }),
    });
    await persistUser(data.usuario);
    return data.usuario;
  }

  async function refreshUser() {
    if (!token) return null;
    const currentUser = await apiRequest(API_ENDPOINTS.me, {
      method: "GET",
      headers: withBearer(token),
    });
    await persistUser(currentUser);
    return currentUser;
  }

  async function clearSession() {
    await AsyncStorage.multiRemove([TOKEN_KEY, USER_KEY]);
    setToken(null);
    setUser(null);
  }

  const value = useMemo(
    () => ({
      token,
      user,
      loading,
      login,
      register,
      updateProfile,
      refreshUser,
      logout: clearSession,
    }),
    [token, user, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth deve ser usado dentro de AuthProvider.");
  }
  return context;
}
