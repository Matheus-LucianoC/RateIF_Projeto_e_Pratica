import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { StatusBar } from "expo-status-bar";

import Field from "../components/Field";
import Message from "../components/Message";
import Screen from "../components/Screen";
import { useAuth } from "../context/AuthContext";

export default function ProfileScreen({ navigation }) {
  const { user, updateProfile } = useAuth();
  const [nome, setNome] = useState(user?.nome || "");
  const [email, setEmail] = useState(user?.email || "");
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setNome(user?.nome || "");
    setEmail(user?.email || "");
  }, [user]);

  async function handleSave() {
    setBusy(true);
    setMessage("");
    setSuccess(false);
    try {
      await updateProfile(nome.trim(), email.trim());
      setSuccess(true);
      setMessage("Perfil atualizado com sucesso.");
    } catch (error) {
      setMessage(error.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <StatusBar style="dark" />
      <Screen>
        <Text style={styles.back} onPress={() => navigation.goBack()}>← Voltar</Text>
        <Text style={styles.eyebrow}>Minha conta</Text>
        <Text style={styles.title}>Perfil</Text>
        <Text style={styles.subtitle}>Os dados abaixo são lidos e atualizados no backend Spring Boot.</Text>

        <Field label="Nome completo" value={nome} onChangeText={setNome} autoCapitalize="words" placeholder="Seu nome" />
        <Field label="E-mail" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="seuemail@exemplo.com" />

        <View style={styles.readonly}>
          <Text style={styles.label}>Perfil</Text>
          <Text style={styles.value}>{user?.perfil || "USUARIO"}</Text>
        </View>
        <View style={styles.readonly}>
          <Text style={styles.label}>Status</Text>
          <Text style={styles.value}>{user?.status ? "Ativo" : "Inativo"}</Text>
        </View>

        <Pressable disabled={busy} onPress={handleSave} style={[styles.primary, busy && styles.disabled]}>
          {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryText}>Salvar alterações</Text>}
        </Pressable>

        <Message text={message} type={success ? "success" : "error"} />
      </Screen>
    </>
  );
}

const styles = StyleSheet.create({
  back: { color: "#2457e6", fontWeight: "700", marginBottom: 20 },
  eyebrow: { color: "#2457e6", fontSize: 11, fontWeight: "800", letterSpacing: 1.4, textTransform: "uppercase" },
  title: { color: "#172033", fontSize: 32, fontWeight: "800", marginTop: 9 },
  subtitle: { color: "#687386", marginTop: 7, marginBottom: 22, lineHeight: 21 },
  readonly: { padding: 15, borderWidth: 1, borderColor: "#dce1e8", borderRadius: 14, marginBottom: 12, backgroundColor: "#f8f9fb" },
  label: { color: "#687386", fontSize: 12, marginBottom: 5 },
  value: { color: "#172033", fontSize: 15, fontWeight: "800" },
  primary: { minHeight: 48, borderRadius: 11, backgroundColor: "#2457e6", alignItems: "center", justifyContent: "center", marginTop: 4 },
  primaryText: { color: "#fff", fontWeight: "800", fontSize: 15 },
  disabled: { opacity: 0.6 },
});
