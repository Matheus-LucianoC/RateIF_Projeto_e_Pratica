import { useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text } from "react-native";
import { StatusBar } from "expo-status-bar";

import Field from "../components/Field";
import Message from "../components/Message";
import Screen from "../components/Screen";
import { useAuth } from "../context/AuthContext";

export default function RegisterScreen({ navigation }) {
  const { register } = useAuth();
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");
  const [showSenha, setShowSenha] = useState(false);
  const [showConfirmar, setShowConfirmar] = useState(false);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleRegister() {
    setMessage("");
    setBusy(true);
    try {
      await register(nome.trim(), email.trim(), senha, confirmarSenha);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <StatusBar style="dark" />
      <Screen>
        <Text style={styles.back} onPress={() => navigation.goBack()}>← Voltar para login</Text>
        <Text style={styles.brand}>Rate<Text style={styles.brandAccent}>IF</Text></Text>
        <Text style={styles.eyebrow}>Novo acesso</Text>
        <Text style={styles.title}>Criar cadastro</Text>
        <Text style={styles.subtitle}>Preencha os dados para criar sua conta.</Text>

        <Field label="Nome completo" value={nome} onChangeText={setNome} autoCapitalize="words" placeholder="Digite seu nome" />
        <Field label="E-mail" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="seuemail@exemplo.com" />
        <Field label="Senha" value={senha} onChangeText={setSenha} secure showPassword={showSenha} onTogglePassword={() => setShowSenha((value) => !value)} placeholder="Mínimo de 6 caracteres" />
        <Field label="Confirmar senha" value={confirmarSenha} onChangeText={setConfirmarSenha} secure showPassword={showConfirmar} onTogglePassword={() => setShowConfirmar((value) => !value)} placeholder="Repita a senha" />

        <Pressable disabled={busy} onPress={handleRegister} style={[styles.primary, busy && styles.disabled]}>
          {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryText}>Criar conta</Text>}
        </Pressable>

        <Message text={message} />
      </Screen>
    </>
  );
}

const styles = StyleSheet.create({
  back: { color: "#2457e6", fontWeight: "700", marginBottom: 18 },
  brand: { fontSize: 30, fontWeight: "800", letterSpacing: -1, color: "#172033" },
  brandAccent: { color: "#2457e6" },
  eyebrow: { color: "#2457e6", fontSize: 11, fontWeight: "800", letterSpacing: 1.4, marginTop: 7, textTransform: "uppercase" },
  title: { color: "#172033", fontSize: 30, fontWeight: "800", marginTop: 17 },
  subtitle: { color: "#687386", fontSize: 15, marginTop: 7, marginBottom: 20 },
  primary: { minHeight: 48, borderRadius: 11, backgroundColor: "#2457e6", alignItems: "center", justifyContent: "center", marginTop: 4 },
  primaryText: { color: "#fff", fontSize: 15, fontWeight: "800" },
  disabled: { opacity: 0.6 },
});
