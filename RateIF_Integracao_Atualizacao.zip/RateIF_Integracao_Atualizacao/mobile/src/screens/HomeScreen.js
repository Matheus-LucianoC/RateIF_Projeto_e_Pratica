import { Pressable, StyleSheet, Text, View } from "react-native";
import { StatusBar } from "expo-status-bar";

import Screen from "../components/Screen";
import { useAuth } from "../context/AuthContext";

export default function HomeScreen({ navigation }) {
  const { user, logout } = useAuth();

  return (
    <>
      <StatusBar style="dark" />
      <Screen>
        <View style={styles.topRow}>
          <Text style={styles.brand}>Rate<Text style={styles.brandAccent}>IF</Text></Text>
          <Pressable onPress={logout} style={styles.secondary}><Text style={styles.secondaryText}>Sair</Text></Pressable>
        </View>

        <Text style={styles.eyebrow}>Acesso mobile</Text>
        <Text style={styles.title}>Olá, <Text style={styles.accent}>{user?.nome || "Usuário"}</Text>!</Text>
        <Text style={styles.subtitle}>O aplicativo está usando a API própria do Spring Boot.</Text>

        <View style={styles.infoCard}>
          <Text style={styles.infoLabel}>E-mail</Text>
          <Text style={styles.infoValue}>{user?.email || "-"}</Text>
        </View>
        <View style={styles.infoCard}>
          <Text style={styles.infoLabel}>Perfil</Text>
          <Text style={styles.infoValue}>{user?.perfil || "USUARIO"}</Text>
        </View>
        <View style={styles.infoCard}>
          <Text style={styles.infoLabel}>Status</Text>
          <Text style={styles.infoValue}>{user?.status ? "Ativo" : "Inativo"}</Text>
        </View>

        <Pressable onPress={() => navigation.navigate("Profile")} style={styles.primary}>
          <Text style={styles.primaryText}>Abrir meu perfil</Text>
        </Pressable>
      </Screen>
    </>
  );
}

const styles = StyleSheet.create({
  topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 24 },
  brand: { fontSize: 28, fontWeight: "800", color: "#172033", letterSpacing: -1 },
  brandAccent: { color: "#2457e6" },
  secondary: { backgroundColor: "#fff", borderWidth: 1, borderColor: "#dce1e8", minHeight: 42, paddingHorizontal: 16, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  secondaryText: { color: "#172033", fontWeight: "800" },
  eyebrow: { color: "#2457e6", fontSize: 11, fontWeight: "800", letterSpacing: 1.4, textTransform: "uppercase" },
  title: { color: "#172033", fontSize: 30, lineHeight: 36, fontWeight: "800", marginTop: 9 },
  accent: { color: "#2457e6" },
  subtitle: { color: "#687386", marginTop: 7, marginBottom: 24, lineHeight: 21 },
  infoCard: { borderWidth: 1, borderColor: "#dce1e8", borderRadius: 14, padding: 16, marginBottom: 12 },
  infoLabel: { color: "#687386", fontSize: 12, marginBottom: 5 },
  infoValue: { color: "#172033", fontSize: 15, fontWeight: "800" },
  primary: { minHeight: 48, borderRadius: 11, backgroundColor: "#2457e6", alignItems: "center", justifyContent: "center", marginTop: 8 },
  primaryText: { color: "#fff", fontWeight: "800", fontSize: 15 },
});
