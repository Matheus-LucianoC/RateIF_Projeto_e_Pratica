import { useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { StatusBar } from "expo-status-bar";

import Field from "../components/Field";
import Message from "../components/Message";
import Screen from "../components/Screen";
import { useAuth } from "../context/AuthContext";

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleLogin() {
    setMessage("");
    setBusy(true);
    try {
      await login(email.trim(), senha);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <StatusBar style="dark" />
      <Screen>
        <Text style={styles.brand}>Rate<Text style={styles.brandAccent}>IF</Text></Text>
        <Text style={styles.eyebrow}>Sistema de Avaliação Escolar</Text>
        <Text style={styles.title}>Entrar</Text>
        <Text style={styles.subtitle}>Acesse sua conta para continuar.</Text>

        <Field label="E-mail" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="seuemail@exemplo.com" />
        <Field label="Senha" value={senha} onChangeText={setSenha} secure showPassword={showPassword} onTogglePassword={() => setShowPassword((value) => !value)} placeholder="Digite sua senha" />

        <Pressable disabled={busy} onPress={handleLogin} style={({ pressed }) => [styles.primary, pressed && styles.pressed, busy && styles.disabled]}>
          {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryText}>Entrar</Text>}
        </Pressable>

        <Message text={message} />

        <View style={styles.divider}>
          <View style={styles.line} />
          <Text style={styles.or}>ou</Text>
          <View style={styles.line} />
        </View>

        <Text style={styles.googleNote}>O Google Auth continua no backend existente e pode ser conectado à próxima etapa do mobile.</Text>

        <Text style={styles.bottomText}>
          Ainda não possui uma conta? {" "}
          <Text style={styles.link} onPress={() => navigation.navigate("Register")}>Criar cadastro</Text>
        </Text>
      </Screen>
    </>
  );
}

const styles = StyleSheet.create({
  brand: { fontSize: 30, fontWeight: "800", letterSpacing: -1, color: "#172033" },
  brandAccent: { color: "#2457e6" },
  eyebrow: { color: "#2457e6", fontSize: 11, fontWeight: "800", letterSpacing: 1.4, marginTop: 7, textTransform: "uppercase" },
  title: { color: "#172033", fontSize: 32, lineHeight: 36, fontWeight: "800", marginTop: 17 },
  subtitle: { color: "#687386", fontSize: 15, marginTop: 7, marginBottom: 22 },
  primary: { minHeight: 48, borderRadius: 11, backgroundColor: "#2457e6", alignItems: "center", justifyContent: "center", marginTop: 2 },
  primaryText: { color: "#fff", fontSize: 15, fontWeight: "800" },
  pressed: { opacity: 0.9 },
  disabled: { opacity: 0.6 },
  divider: { flexDirection: "row", alignItems: "center", gap: 10, marginVertical: 22 },
  line: { flex: 1, height: 1, backgroundColor: "#dce1e8" },
  or: { color: "#8993a2", fontSize: 13 },
  googleNote: { color: "#687386", textAlign: "center", fontSize: 12, lineHeight: 18 },
  bottomText: { color: "#687386", textAlign: "center", marginTop: 24, fontSize: 14 },
  link: { color: "#2457e6", fontWeight: "800" },
});
