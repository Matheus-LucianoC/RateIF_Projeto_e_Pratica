import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";

export default function Field({ label, secure, showPassword, onTogglePassword, ...props }) {
  return (
    <View style={styles.wrapper}>
      <Text style={styles.label}>{label}</Text>
      <View>
        <TextInput
          {...props}
          secureTextEntry={secure && !showPassword}
          placeholderTextColor="#8993a2"
          style={[styles.input, secure && styles.inputWithButton]}
        />
        {secure ? (
          <Pressable onPress={onTogglePassword} style={styles.toggle}>
            <Text style={styles.toggleText}>{showPassword ? "Ocultar" : "Mostrar"}</Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { marginBottom: 14 },
  label: { color: "#172033", fontWeight: "700", fontSize: 14, marginBottom: 7 },
  input: {
    height: 48,
    borderWidth: 1,
    borderColor: "#dce1e8",
    borderRadius: 11,
    paddingHorizontal: 14,
    backgroundColor: "#fff",
    color: "#172033",
    fontSize: 15,
  },
  inputWithButton: { paddingRight: 88 },
  toggle: { position: "absolute", right: 8, top: 0, height: 48, justifyContent: "center", paddingHorizontal: 7 },
  toggleText: { color: "#2457e6", fontWeight: "700" },
});
