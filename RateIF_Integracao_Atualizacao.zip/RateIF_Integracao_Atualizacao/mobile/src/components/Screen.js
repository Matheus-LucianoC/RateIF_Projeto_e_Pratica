import { SafeAreaView, ScrollView, StyleSheet, View } from "react-native";

export default function Screen({ children, contentContainerStyle }) {
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={[styles.container, contentContainerStyle]} keyboardShouldPersistTaps="handled">
        <View style={styles.card}>{children}</View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f3f5f8" },
  container: { flexGrow: 1, justifyContent: "center", padding: 20 },
  card: {
    width: "100%",
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#e6e9ef",
    borderRadius: 22,
    padding: 22,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 8 },
  },
});
