import { StyleSheet, Text } from "react-native";

export default function Message({ text, type = "error" }) {
  if (!text) return null;
  return <Text style={[styles.base, type === "success" ? styles.success : styles.error]}>{text}</Text>;
}

const styles = StyleSheet.create({
  base: { marginTop: 10, padding: 12, borderRadius: 10, fontSize: 14, lineHeight: 20 },
  error: { backgroundColor: "#fff0f1", color: "#c93443" },
  success: { backgroundColor: "#ebf8f1", color: "#19734b" },
});
