import { API_URL } from "../config/api";

export async function apiRequest(path, options = {}) {
  const headers = {
    Accept: "application/json",
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };

  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers,
  });

  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { mensagem: "O servidor retornou uma resposta inválida." };
  }

  if (!response.ok) {
    const error = new Error(data.mensagem || `Erro HTTP ${response.status}`);
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
}

export function withBearer(token) {
  return token
    ? { Authorization: `Bearer ${token}` }
    : {};
}
