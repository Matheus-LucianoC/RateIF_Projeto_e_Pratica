const DEFAULT_API_URL = "http://192.168.0.100:8080";

export const API_URL = (process.env.EXPO_PUBLIC_API_URL || DEFAULT_API_URL).replace(/\/$/, "");

export const API_ENDPOINTS = {
  login: "/api/mobile/auth/login",
  cadastro: "/api/mobile/auth/cadastro",
  me: "/api/mobile/usuarios/me",
  profile: "/api/mobile/usuarios/me",
};
